package com.mc3.map;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
